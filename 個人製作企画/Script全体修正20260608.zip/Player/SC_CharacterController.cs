using UnityEngine;
//�v���C���[�R���g���[���[�@�ړ��A�_�b�V���A�W�����v�A���_�A�A�j���[�V�����A�g
[RequireComponent(typeof(CharacterController))]
public class SC_CharacterController : MonoBehaviour
{
    //�ړ����x
    public float speed = 7.5f;
    public float dashSpeed = 12.0f;
    public KeyCode dashKey = KeyCode.LeftShift;

    //�W�����v��
    public float jumpSpeed = 6.0f;
    public float gravity = 35.0f;

    //���_�ړ�
    public Camera playerCamera;
    public float lookSpeed = 2.0f;
    public float lookXLimit = 45.0f;


    public Animator animator;
    public HeldItemController heldItemController;
    private CharacterController characterController;
    [HideInInspector]
    public Vector3 moveDirection = Vector3.zero;
    private Vector2 rotation = Vector2.zero;
    [HideInInspector]
    public bool canMove = true;
    [HideInInspector]
    public bool isDashing = false;
    private float inputX;
    private float inputZ;
    //����ڒn����
    private bool stableGrounded;
    private float groundedRememberTime = 0.1f;
    private float groundedTimer = 0f;

    //�����̃J�N�J�N�����ǂ��ɂ�����p
    [Header("�󒆑���")]
    public float airControlSmooth = 8f;
    public float groundControlSmooth = 20f;

    void Start()
    {
        characterController = GetComponent<CharacterController>();
        rotation.y = transform.eulerAngles.y;
    }
    void Update()
    {
        HandleMovement();
        HandleLook();
        HandleAnimation();
    }
    void HandleMovement()
    {
        bool rawGrounded = characterController.isGrounded;

        inputZ = canMove ? Input.GetAxisRaw("Vertical") : 0f;
        inputX = canMove ? Input.GetAxisRaw("Horizontal") : 0f;

        if (Mathf.Abs(inputZ) < 0.1f) inputZ = 0f;
        if (Mathf.Abs(inputX) < 0.1f) inputX = 0f;

        if (rawGrounded)
        {
            groundedTimer = groundedRememberTime;
            stableGrounded = true;
        }
        else
        {
            groundedTimer -= Time.deltaTime;
            if (groundedTimer <= 0f)
            {
                stableGrounded = false;
            }
        }

        Vector3 forward = transform.TransformDirection(Vector3.forward);
        Vector3 right = transform.TransformDirection(Vector3.right);

        bool hasMovementInput =
            Mathf.Abs(inputZ) > 0.1f ||
            Mathf.Abs(inputX) > 0.1f;

        isDashing =
            canMove &&
            hasMovementInput &&
            Input.GetKey(dashKey);

        float currentSpeed = isDashing ? dashSpeed : speed;

        Vector3 horizontalMove =
            (forward * inputZ + right * inputX) * currentSpeed;

        //�󒆂ł͑O�㍶�E�ړ����ł��Ȃ�(��)
        /*if (rawGrounded)
        {
            Vector3 forward = transform.TransformDirection(Vector3.forward);
            Vector3 right = transform.TransformDirection(Vector3.right);
            bool hasMovementInput = Mathf.Abs(inputZ) > 0.1f || Mathf.Abs(inputX) > 0.1f; isDashing = canMove && hasMovementInput && Input.GetKey(dashKey);
            float currentSpeed = isDashing ? dashSpeed : speed;
            moveDirection = (forward * inputZ + right * inputX) * currentSpeed;

            //�ڒn���͏����������ɂ��Đڒn�����肳����
            moveDirection.y = -2f;
        }*/

        //�󒆂ł��ړ��ł���悤�ɂ���(�V)

        //���ꂾ�ƃJ�N�J�N�ȓ����ɂȂ�
        //moveDirection.x = horizontalMove.x;
        //moveDirection.z = horizontalMove.z;
        //�J�N�J�N�����y��
        float smooth = rawGrounded ? groundControlSmooth : airControlSmooth;

        moveDirection.x = Mathf.Lerp(
            moveDirection.x,
            horizontalMove.x,
            Time.deltaTime * smooth
        );

        moveDirection.z = Mathf.Lerp(
            moveDirection.z,
            horizontalMove.z,
            Time.deltaTime * smooth
        );

        if (rawGrounded)
        {
            moveDirection.y = -2f;

            if (Input.GetButtonDown("Jump") && canMove)
            {
                moveDirection.y = jumpSpeed;

                //�_�b�V���W�����v���ɑ������ăt���b�Ƃ���̂�h��
                moveDirection.x *= 0.75f;
                moveDirection.z *= 0.75f;

                if (animator != null)
                {
                    animator.SetTrigger("Jump");
                }

                stableGrounded = false;
                groundedTimer = 0f;
            }
        }
        else
        {
            moveDirection.y -= gravity * Time.deltaTime;
        }

        characterController.Move(moveDirection * Time.deltaTime);
    }

    void HandleLook()
    {
        bool isRotatingItem = heldItemController != null && heldItemController.IsRotatingItem;
        if (canMove && !isRotatingItem)
        {
            rotation.y += Input.GetAxis("Mouse X") * lookSpeed;
            rotation.x += -Input.GetAxis("Mouse Y") * lookSpeed;
            rotation.x = Mathf.Clamp(rotation.x, -lookXLimit, lookXLimit);
            playerCamera.transform.localRotation = Quaternion.Euler(rotation.x, 0, 0);
            transform.eulerAngles = new Vector3(0, rotation.y, 0);
        }
    }
    void HandleAnimation()
    {
        if (animator == null)
            return;
        float moveMultiplier = isDashing ? 2f : 1f;
        float animX = inputX * moveMultiplier;
        float animZ = inputZ * moveMultiplier;
        animator.SetFloat("MoveX", animX, 0.1f, Time.deltaTime);
        animator.SetFloat("MoveZ", animZ, 0.1f, Time.deltaTime);
        animator.SetBool("IsGrounded", stableGrounded);
    }
    
    
    //�L�����N�^�[�����W�b�g�{�f�B�ɐG���Ɖ����o����
    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        //�������������Rigidbody�擾
        Rigidbody rb = hit.collider.attachedRigidbody;

        //Rigidbody�������Ȃ牽�����Ȃ�
        if (rb == null)
            return;

        //�Œ肳��Ă镨�͉����Ȃ�
        if (rb.isKinematic)
            return;

        //�������͉����Ȃ�
        if (hit.moveDirection.y < -0.3f)
            return;

        //�v���C���[���i�񂾕���
        Vector3 pushDir = new Vector3(
            hit.moveDirection.x,
            0f,
            hit.moveDirection.z
        );

        //�͂�������
        rb.AddForce(pushDir *   1f, ForceMode.Impulse);
    }

}