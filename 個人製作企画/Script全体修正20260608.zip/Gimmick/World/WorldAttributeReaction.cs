using System.Collections.Generic;
using UnityEngine;
//�A�C�e���ɂ�锽��(�j��Ȃ�)

[System.Serializable]
public class WorldAttributeReaction
{
    public string reactionName;
    public string reactionType;
    public List<string> requiredAttributes = new List<string>();
    [TextArea] public string message;
}
